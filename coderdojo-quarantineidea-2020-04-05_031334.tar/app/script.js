function Sports() {
  var sports = [
    "ride your bike",
    "go for a jog",
    "do ten pushups",
    "have a dance party",
    "play wii sports",
    "go to the park **make sure to practice social distancing!!**",
    "play soccer in your backyard",
    "try yoga or meditation"
  ];

  var SportsOutput = sports[Math.round(Math.random() * (sports.length - 1))];

  document.getElementById("ideas").innerHTML = "<div>" + SportsOutput + "</div>";
}

function Music() {
  var music = [
    "learn to play the guitar",
    "learn to sing a new song",
    "perform a music concert for your family",
    "have a music competition with your family",
    "create a music video",
    "binge watch 'The Voice' ",
    "learn a Tik Tok dance"
  ];

  var MusicOutput = music[Math.round(Math.random() * (music.length - 1))];

  document.getElementById("ideas").innerHTML = "<div>" + MusicOutput + "</div>";
}

function Art() {
  var art = [
    "learn to paint",
    "learn calligraphy",
    "learn to draw your favorite celebrity",
    "make thank you cards and mail them out",
    "fill in a coloring book",
    "pursue photography",
    "write a poem",
    "learn a new language",
    "knit or crochet",
    "learn how to braid hair"
  ];

  var ArtOutput = art[Math.round(Math.random() * (art.length - 1))];

  document.getElementById("ideas").innerHTML = "<div>" + ArtOutput + "</div>";
}

function Cooking() {
  var cooking = [
    "bake cookies or brownies for your entire family",
    "having a 'Great British Baking Show' with your family",
    "make a meal using only the microwave",
    "make a dish you've never heard of",
    "have an indoor picnic",
    "create your OWN recipe"
  ];

  var CookingOutput = cooking[Math.round(Math.random() * (cooking.length - 1))];

  document.getElementById("ideas").innerHTML =
    "<div>" + CookingOutput + "</div>";
}
